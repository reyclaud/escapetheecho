<?php
defined('_JEXEC') or die('Restricted access');
?>

<div class="content-wrapper">
    <h1 class="content-title"></h1>

    <table class="content-table">
        <col width="25%">
        <col width="25%">
        <col width="25%">
        <col width="25%">
        <thead>
            <tr>
                <th colspan="4">Backend - Briefing Builder</th>
            </tr>
        </thead>
        <tbody>
            <?php /*
              <tr>
              <td>Select Quiz Category</td>
              <td>
              <select name="category">
              <option value="">-- Select Category --</option>
              <option value="44">Entertainment & Culture</option>
              <option value="61">Power & Politics</option>
              <option value="46">Sports & Play</option>
              <option value="48">Home & Community</option>
              <option value="51">Beliefs & Ideas</option>
              <option value="52">Science & Technology</option>
              </select>
              </td>
              </tr>
              <tr>
              <td>Select Question</td>
              <td class="select-question-td">
              <select name="question" disabled="disabled">
              <option value="">-- Select Question --</option>
              </select>
              </td>
              </tr>
              <tr>
              <td>Select Answer</td>
              <td class="select-answer-td">
              <select name="answers" disabled="disabled">
              <option value="">-- Select Answer --</option>
              </select>
              </td>
              </tr>
             */ ?>
            <tr>
                <td colspan="2">URL</td>
                <td colspan="2">
                    <input type="text" name="briefing_link" class="briefing-input-fields" placeholder="http://www.url.com" />
                    <div class="error-msg">*Wrong url format. Please include http:// or https://.</div>
                </td>
            </tr>
            <tr>
                <td colspan="2">Introduction</td>
                <td colspan="2">
                    <textarea name="briefing_introduction" class="briefing-input-fields"></textarea>
                    <div class="error-msg">*Introduction can't be empty. Please check.</div>
                </td>
            </tr> 
            <tr>
                <td colspan="2">Nationality</td>
                <td colspan="2">
                    <select name="nationality" class="country-select" multiple>
                        <option value="AF">Afghanistan</option>
                        <option value="AX">Aland Islands</option>
                        <option value="AL">Albania</option>
                        <option value="DZ">Algeria</option>
                        <option value="AS">American Samoa</option>
                        <option value="AD">Andorra</option>
                        <option value="AO">Angola</option>
                        <option value="AI">Anguilla</option>
                        <option value="AQ">Antarctica</option>
                        <option value="AG">Antigua and Barbuda</option>
                        <option value="AR">Argentina</option>
                        <option value="AM">Armenia</option>
                        <option value="AW">Aruba</option>
                        <option value="AU">Australia</option>
                        <option value="AT">Austria</option>
                        <option value="AZ">Azerbaijan</option>
                        <option value="BS">Bahamas</option>
                        <option value="BH">Bahrain</option>
                        <option value="BD">Bangladesh</option>
                        <option value="BB">Barbados</option>
                        <option value="BY">Belarus</option>
                        <option value="BE">Belgium</option>
                        <option value="BZ">Belize</option>
                        <option value="BJ">Benin</option>
                        <option value="BM">Bermuda</option>
                        <option value="BT">Bhutan</option>
                        <option value="BO">Bolivia, Plurinational State of</option>
                        <option value="BQ">Bonaire, Sint Eustatius and Saba</option>
                        <option value="BA">Bosnia and Herzegovina</option>
                        <option value="BW">Botswana</option>
                        <option value="BV">Bouvet Island</option>
                        <option value="BR">Brazil</option>
                        <option value="IO">British Indian Ocean Territory</option>
                        <option value="BN">Brunei Darussalam</option>
                        <option value="BG">Bulgaria</option>
                        <option value="BF">Burkina Faso</option>
                        <option value="BI">Burundi</option>
                        <option value="KH">Cambodia</option>
                        <option value="CM">Cameroon</option>
                        <option value="CA">Canada</option>
                        <option value="CV">Cape Verde</option>
                        <option value="KY">Cayman Islands</option>
                        <option value="CF">Central African Republic</option>
                        <option value="TD">Chad</option>
                        <option value="CL">Chile</option>
                        <option value="CN">China</option>
                        <option value="CX">Christmas Island</option>
                        <option value="CC">Cocos (Keeling) Islands</option>
                        <option value="CO">Colombia</option>
                        <option value="KM">Comoros</option>
                        <option value="CG">Congo</option>
                        <option value="CD">Congo, the Democratic Republic of the</option>
                        <option value="CK">Cook Islands</option>
                        <option value="CR">Costa Rica</option>
                        <option value="CI">C�te d'Ivoire</option>
                        <option value="HR">Croatia</option>
                        <option value="CU">Cuba</option>
                        <option value="CW">Cura�ao</option>
                        <option value="CY">Cyprus</option>
                        <option value="CZ">Czech Republic</option>
                        <option value="DK">Denmark</option>
                        <option value="DJ">Djibouti</option>
                        <option value="DM">Dominica</option>
                        <option value="DO">Dominican Republic</option>
                        <option value="EC">Ecuador</option>
                        <option value="EG">Egypt</option>
                        <option value="SV">El Salvador</option>
                        <option value="GQ">Equatorial Guinea</option>
                        <option value="ER">Eritrea</option>
                        <option value="EE">Estonia</option>
                        <option value="ET">Ethiopia</option>
                        <option value="FK">Falkland Islands (Malvinas)</option>
                        <option value="FO">Faroe Islands</option>
                        <option value="FJ">Fiji</option>
                        <option value="FI">Finland</option>
                        <option value="FR">France</option>
                        <option value="GF">French Guiana</option>
                        <option value="PF">French Polynesia</option>
                        <option value="TF">French Southern Territories</option>
                        <option value="GA">Gabon</option>
                        <option value="GM">Gambia</option>
                        <option value="GE">Georgia</option>
                        <option value="DE">Germany</option>
                        <option value="GH">Ghana</option>
                        <option value="GI">Gibraltar</option>
                        <option value="GR">Greece</option>
                        <option value="GL">Greenland</option>
                        <option value="GD">Grenada</option>
                        <option value="GP">Guadeloupe</option>
                        <option value="GU">Guam</option>
                        <option value="GT">Guatemala</option>
                        <option value="GG">Guernsey</option>
                        <option value="GN">Guinea</option>
                        <option value="GW">Guinea-Bissau</option>
                        <option value="GY">Guyana</option>
                        <option value="HT">Haiti</option>
                        <option value="HM">Heard Island and McDonald Islands</option>
                        <option value="VA">Holy See (Vatican City State)</option>
                        <option value="HN">Honduras</option>
                        <option value="HK">Hong Kong</option>
                        <option value="HU">Hungary</option>
                        <option value="IS">Iceland</option>
                        <option value="IN">India</option>
                        <option value="ID">Indonesia</option>
                        <option value="IR">Iran, Islamic Republic of</option>
                        <option value="IQ">Iraq</option>
                        <option value="IE">Ireland</option>
                        <option value="IM">Isle of Man</option>
                        <option value="IL">Israel</option>
                        <option value="IT">Italy</option>
                        <option value="JM">Jamaica</option>
                        <option value="JP">Japan</option>
                        <option value="JE">Jersey</option>
                        <option value="JO">Jordan</option>
                        <option value="KZ">Kazakhstan</option>
                        <option value="KE">Kenya</option>
                        <option value="KI">Kiribati</option>
                        <option value="KP">Korea, Democratic People's Republic of</option>
                        <option value="KR">Korea, Republic of</option>
                        <option value="KW">Kuwait</option>
                        <option value="KG">Kyrgyzstan</option>
                        <option value="LA">Lao People's Democratic Republic</option>
                        <option value="LV">Latvia</option>
                        <option value="LB">Lebanon</option>
                        <option value="LS">Lesotho</option>
                        <option value="LR">Liberia</option>
                        <option value="LY">Libya</option>
                        <option value="LI">Liechtenstein</option>
                        <option value="LT">Lithuania</option>
                        <option value="LU">Luxembourg</option>
                        <option value="MO">Macao</option>
                        <option value="MK">Macedonia, the former Yugoslav Republic of</option>
                        <option value="MG">Madagascar</option>
                        <option value="MW">Malawi</option>
                        <option value="MY">Malaysia</option>
                        <option value="MV">Maldives</option>
                        <option value="ML">Mali</option>
                        <option value="MT">Malta</option>
                        <option value="MH">Marshall Islands</option>
                        <option value="MQ">Martinique</option>
                        <option value="MR">Mauritania</option>
                        <option value="MU">Mauritius</option>
                        <option value="YT">Mayotte</option>
                        <option value="MX">Mexico</option>
                        <option value="FM">Micronesia, Federated States of</option>
                        <option value="MD">Moldova, Republic of</option>
                        <option value="MC">Monaco</option>
                        <option value="MN">Mongolia</option>
                        <option value="ME">Montenegro</option>
                        <option value="MS">Montserrat</option>
                        <option value="MA">Morocco</option>
                        <option value="MZ">Mozambique</option>
                        <option value="MM">Myanmar</option>
                        <option value="NA">Namibia</option>
                        <option value="NR">Nauru</option>
                        <option value="NP">Nepal</option>
                        <option value="NL">Netherlands</option>
                        <option value="NC">New Caledonia</option>
                        <option value="NZ">New Zealand</option>
                        <option value="NI">Nicaragua</option>
                        <option value="NE">Niger</option>
                        <option value="NG">Nigeria</option>
                        <option value="NU">Niue</option>
                        <option value="NF">Norfolk Island</option>
                        <option value="MP">Northern Mariana Islands</option>
                        <option value="NO">Norway</option>
                        <option value="OM">Oman</option>
                        <option value="PK">Pakistan</option>
                        <option value="PW">Palau</option>
                        <option value="PS">Palestinian Territory, Occupied</option>
                        <option value="PA">Panama</option>
                        <option value="PG">Papua New Guinea</option>
                        <option value="PY">Paraguay</option>
                        <option value="PE">Peru</option>
                        <option value="PH">Philippines</option>
                        <option value="PN">Pitcairn</option>
                        <option value="PL">Poland</option>
                        <option value="PT">Portugal</option>
                        <option value="PR">Puerto Rico</option>
                        <option value="QA">Qatar</option>
                        <option value="RE">Reunion</option>
                        <option value="RO">Romania</option>
                        <option value="RU">Russian Federation</option>
                        <option value="RW">Rwanda</option>
                        <option value="BL">Saint Barthelemy</option>
                        <option value="SH">Saint Helena, Ascension and Tristan da Cunha</option>
                        <option value="KN">Saint Kitts and Nevis</option>
                        <option value="LC">Saint Lucia</option>
                        <option value="MF">Saint Martin (French part)</option>
                        <option value="PM">Saint Pierre and Miquelon</option>
                        <option value="VC">Saint Vincent and the Grenadines</option>
                        <option value="WS">Samoa</option>
                        <option value="SM">San Marino</option>
                        <option value="ST">Sao Tome and Principe</option>
                        <option value="SA">Saudi Arabia</option>
                        <option value="SN">Senegal</option>
                        <option value="RS">Serbia</option>
                        <option value="SC">Seychelles</option>
                        <option value="SL">Sierra Leone</option>
                        <option value="SG">Singapore</option>
                        <option value="SX">Sint Maarten (Dutch part)</option>
                        <option value="SK">Slovakia</option>
                        <option value="SI">Slovenia</option>
                        <option value="SB">Solomon Islands</option>
                        <option value="SO">Somalia</option>
                        <option value="ZA">South Africa</option>
                        <option value="GS">South Georgia and the South Sandwich Islands</option>
                        <option value="SS">South Sudan</option>
                        <option value="ES">Spain</option>
                        <option value="LK">Sri Lanka</option>
                        <option value="SD">Sudan</option>
                        <option value="SR">Suriname</option>
                        <option value="SJ">Svalbard and Jan Mayen</option>
                        <option value="SZ">Swaziland</option>
                        <option value="SE">Sweden</option>
                        <option value="CH">Switzerland</option>
                        <option value="SY">Syrian Arab Republic</option>
                        <option value="TW">Taiwan, Province of China</option>
                        <option value="TJ">Tajikistan</option>
                        <option value="TZ">Tanzania, United Republic of</option>
                        <option value="TH">Thailand</option>
                        <option value="TL">Timor-Leste</option>
                        <option value="TG">Togo</option>
                        <option value="TK">Tokelau</option>
                        <option value="TO">Tonga</option>
                        <option value="TT">Trinidad and Tobago</option>
                        <option value="TN">Tunisia</option>
                        <option value="TR">Turkey</option>
                        <option value="TM">Turkmenistan</option>
                        <option value="TC">Turks and Caicos Islands</option>
                        <option value="TV">Tuvalu</option>
                        <option value="UG">Uganda</option>
                        <option value="UA">Ukraine</option>
                        <option value="AE">United Arab Emirates</option>
                        <option value="GB">United Kingdom</option>
                        <option value="US">United States</option>
                        <option value="UM">United States Minor Outlying Islands</option>
                        <option value="UY">Uruguay</option>
                        <option value="UZ">Uzbekistan</option>
                        <option value="VU">Vanuatu</option>
                        <option value="VE">Venezuela, Bolivarian Republic of</option>
                        <option value="VN">Vietnam</option>
                        <option value="VG">Virgin Islands, British</option>
                        <option value="VI">Virgin Islands, U.S.</option>
                        <option value="WF">Wallis and Futuna</option>
                        <option value="EH">Western Sahara</option>
                        <option value="YE">Yemen</option>
                        <option value="ZM">Zambia</option>
                        <option value="ZW">Zimbabwe</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <button type="button" id="send-to-all"><span>Send to all</span></button>
                    <button type="button" id="send-to-matching"><span>Send to matching</span></button>
                </td>
            </tr>
            <tr>
                <td colspan="4"><button type="button" id="search-answer"><span>Search Answer</span></button></td>            
            </tr>
            <tr>
                <td colspan="4" style="text-align: center; ">ANSWERS - Total IDs[<span class="answers-count">0</span>]</td>            
            </tr>
            <tr class="after-selections">
                <?php /* <td colspan="2"><button type="button" id="save-to-briefings"><span>Save to briefings</span></button></td> */ ?>
                <td colspan="4"><button type="button" id="start-new-link"><span>Start new link [Save]</span></button></td>
            </tr>
        </tbody>
    </table>
</div>

<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery("select[name=category]").change(function () {
            briefingBuilder.getQuestions();
        });
        jQuery("#select-question-answers").click(function () {
            briefingBuilder.selectQuestions();
        });
        jQuery("#search-answer").click(function () {
            briefingBuilder.showQuestionAnswers();
        });
        jQuery("#send-to-all").click(function () {
            briefingBuilder.sendToAll();
        });
        jQuery("#send-to-matching").click(function () {
            briefingBuilder.sendMatching();
        });
        jQuery("#save-to-briefings").click(function () {
            briefingBuilder.showLinkReview();
        });
        jQuery("#start-new-link").click(function () {
            briefingBuilder.save();
        });

        jQuery("select[name=nationality]").children("option").each(function () {
            jQuery(this).attr("selected", true);
        });

        briefingBuilder = {
            ids: [],
            allMatching: 0,
            save: function () {
                jQuery.ajax({
                    url: "<?php echo JURI::current(); ?>",
                    data: {
                        uids: (briefingBuilder.ids).toString(),
                        url: jQuery("input[name=briefing_link]").val(),
                        intro: jQuery("textarea[name=briefing_introduction]").val(),
                        task: 'backend.save',
                        allMatching: briefingBuilder.allMatching
                    },
                    type: "post",
                    beforeSend: function () {
                        var hasErrors = false;
                        if (!briefingBuilder.validURL(jQuery("input[name=briefing_link]").val())) {
                            jQuery("input[name=briefing_link]").siblings("div.error-msg").slideDown("fast");
                            jQuery("input[name=briefing_link]").siblings("div.error-msg").delay(400).fadeOut(400).delay(400).fadeIn(400).delay(400).fadeIn(400);
                            hasErrors = true;
                        } else {
                            jQuery("input[name=briefing_link]").siblings("div.error-msg").slideUp("fast");
                        }

                        if (jQuery("textarea[name=briefing_introduction]").val() == '') {
                            jQuery("textarea[name=briefing_introduction]").siblings("div.error-msg").slideDown("fast");
                            jQuery("textarea[name=briefing_introduction]").siblings("div.error-msg").delay(400).fadeOut(400).delay(400).fadeIn(400).delay(400).fadeIn(400);;
                            hasErrors = true;
                        } else {
                            jQuery("textarea[name=briefing_introduction]").siblings("div.error-msg").slideUp("fast");
                        }
                        
                        if(!hasErrors && jQuery("tr.selected-qqa").length < 1){
                            jQuery("button#search-answer").click();
                            hasErrors = true;
                        }

                        return !hasErrors;

                    },
                    success: function (resp) {
                        if (resp == 1) {
                            alert("Saved successfully!");
                            jQuery("input[name=briefing_link]").val("");
                            jQuery("textarea[name=briefing_introduction]").val("");
                            jQuery("tr.selected-qqa").remove();
                            jQuery(".answers-count").text(0);

                            briefingBuilder.ids = [];
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR + ' - ' + textStatus + ' - ' + errorThrown);
                    }
                });
            },
            showQuestionAnswers: function () {
                jQuery.ajax({
                    url: "<?php echo JURI::current(); ?>",
                    data: "quizId=61&task=backend.showQuestionAnswers",
                    type: "get",
                    beforeSend: function () {
                        briefingBuilder.overlay();
                    },
                    success: function (resp) {
                        if (jQuery(".close-overlay").length < 1) {
                            jQuery("#overlay-content-wrap").append('<div class=\"close-overlay\" onclick=\"briefingBuilder.closeOverlay();\">[x]close</div>');
                            jQuery("#overlay-content-wrap").append(resp);
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR + ' - ' + textStatus + ' - ' + errorThrown);
                    }
                });
            },
            showLinkReview: function () {
                jQuery.ajax({
                    url: "<?php echo JURI::current(); ?>",
                    data: {ids: briefingBuilder.ids} + "&task=backend.showLinkReview&url=" + jQuery("input[name=briefing_link]").val() + "&description=" + jQuery("input[name=briefing_introduction]").val(),
                    type: "post",
                    beforeSend: function () {

                    },
                    success: function (resp) {
                        alert(resp);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR + ' - ' + textStatus + ' - ' + errorThrown);
                    }
                });
            },
            selectQuestions: function () {
                jQuery.ajax({
                    url: "<?php echo JURI::current(); ?>",
                    data: "quizId=" + jQuery("select[name=category]").val() + '&task=backend.showAnswers',
                    type: "get",
                    beforeSend: function () {
                        briefingBuilder.overlay();
                    },
                    success: function (resp) {

                        jQuery("#overlay-content-wrap").append('<div class=\"close-overlay\" onclick=\"briefingBuilder.closeOverlay();\">[x]close</div>');
                        jQuery("#overlay-content-wrap").append(resp);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR + ' - ' + textStatus + ' - ' + errorThrown);
                    }
                });
            },
            getQuestions: function () {
                jQuery.ajax({
                    url: "<?php echo JURI::current(); ?>",
                    data: "quizId=" + jQuery("select[name=category]").val() + '&task=backend.getQuestions',
                    type: "get",
                    success: function (resp) {

                        jQuery(".select-question-td").html(resp);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR + ' - ' + textStatus + ' - ' + errorThrown);
                    }
                });
            },
            getAnswers: function (ths) {
                var selectedQuestionText = jQuery(ths).children("option:selected").text();
                var selectedQuestionValue = jQuery(ths).val();
                jQuery.ajax({
                    url: "<?php echo JURI::current(); ?>",
                    data: "quizId=" + jQuery("select[name=category]").val() + "&question=" + selectedQuestionValue + '&task=backend.getAnswers',
                    type: "get",
                    beforeSend: function () {
                        jQuery("div.selected-question").remove();
                        jQuery(ths).after("<div class=\"selected-question\"><i class=\"fa fa-arrow-right\" /> " + selectedQuestionText + "</div>");
                    },
                    success: function (resp) {
                        jQuery(".select-answer-td").html(resp);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR + ' - ' + textStatus + ' - ' + errorThrown);
                    }
                });
            },
            getRespondents: function (ths) {
                var selectedAnswerText = jQuery(ths).children("option:selected").text();
                var selectedAnswerValue = jQuery(ths).val();
                jQuery.ajax({
                    url: "<?php echo JURI::current(); ?>",
                    data: "quizId=" + jQuery("select[name=category]").val() + "&question=" + selectedAnswerValue + '&task=backend.getAnswers',
                    type: "get",
                    beforeSend: function () {
                        jQuery("div.selected-answer").remove();
                        jQuery(ths).after("<div class=\"selected-answer\"><i class=\"fa fa-arrow-right\" /> " + selectedAnswerText + "</div>");
                    },
                    success: function (resp) {

                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR + ' - ' + textStatus + ' - ' + errorThrown);
                    }
                });
            },
            overlay: function () {
                if (jQuery("#overlay-bg").length < 1) {
                    jQuery("body").append("<div id=\"overlay-bg\" />");
                    jQuery("body").append("<div id=\"overlay-content-wrap\" />");
                } else {
                    jQuery("#overlay-bg").fadeIn("fast");
                    jQuery("#overlay-content-wrap").fadeIn("fast");
                }
            },
            closeOverlay: function () {
                jQuery("#overlay-content-wrap").fadeOut("fast");
                jQuery("#overlay-bg").fadeOut("fast");
            },
            removeQA: function (ids, qaid) {
                var _ids = briefingBuilder.ids;
                var index = _ids.indexOf(ids);
                if (confirm("Are you sure you want to remove this Question/Answer from the list?")) {
                    jQuery("button.remove-answer-btn-" + qaid).click();
                    jQuery("tr.quiz-id-" + qaid + "-selected").fadeOut("fast", function () {
                        jQuery(this).remove();
                        if (index >= 0) {
                            _ids.splice(index, 1);
                        }
                    });

                    (briefingBuilder.ids).splice(index, 1);

                    if (jQuery("#send-to-matching").hasClass("selected")) {
                        briefingBuilder.sendMatching();
                    } else {
                        briefingBuilder.sendToAll();
                    }

                }
            },
            sendToAll: function () {
                var _ids = briefingBuilder.ids;
                var uids = [];
                var _uids = [];
                var uids_ = [];
                briefingBuilder.allMatching = 0;
                jQuery.each(_ids, function (index, value) {
                    uids_ = value.split("|");
                    _uids = uids_[1].split(";");
                    jQuery.each(_uids, function (index, value) {
                        if (uids.indexOf(value) < 0) {
                            uids.push(value);
                        }
                    });
                });

                jQuery("#send-to-all").addClass("selected");
                jQuery("#send-to-matching").removeClass("selected");
                jQuery(".answers-count").text(uids.length);
            },
            sendMatching: function () {
                var _ids = briefingBuilder.ids;
                var nxtElement = [], nxtElement2 = [];
                var commonElements = [];
                briefingBuilder.allMatching = 1;
                jQuery.each(_ids, function (index, value) {
                    var _arr = value.split("|");
                    var _arr2 = _arr[1].split(";");
                    if (_ids.length > (index + 1)) {

                        nxtElement = (_ids[index + 1]).split("|");
                        nxtElement2 = nxtElement[1].split(";");
                        jQuery.each(briefingBuilder.idIntersect(_arr2, nxtElement2), function (index, value) {
                            if (commonElements.indexOf(value) < 0) {
                                commonElements.push(value);
                            }
                        });
                        console.log(commonElements);
                    }
                });

                jQuery("#send-to-matching").addClass("selected");
                jQuery("#send-to-all").removeClass("selected");
                jQuery(".answers-count").text(commonElements.length);
            },
            idIntersect: function (a, b) {
                var t;
                if (b.length > a.length)
                    t = b, b = a, a = t;
                return a.filter(function (e) {
                    return b.indexOf(e) > -1;
                });
            },
            validURL: function (uri) {
                var regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
                return regexp.test(uri);
            }
        };
    }
    );
</script>