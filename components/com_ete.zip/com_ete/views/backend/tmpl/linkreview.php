<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>

<table class="link-review-table">
    <thead>
        <tr>
            <th style="text-align: center" colspan="6">WEEK: 17/07/2017 - 23/07/2017</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th>Link</th>
            <th>Answer</th>
            <th>IPs</th>
            <th></th>
            <th>Count</th>
            <th>All/Matching</th>
        </tr>
        <?php
        foreach ($this->get('LinkReviews') as $link) {
            ?>
            <tr>
                <td>
                    <div class="link_url">URL: <?php echo $link->url; ?></div>
                    <div class="link_intro">Introduction: <?php echo $link->intro; ?></div>
                </td>
                <td>
                    <?php echo $link->respondents; ?>
                </td>
                <td></td>
                <td><a href="#">Edit</a></td>
                <td><?php echo 0; ?></td>
                <td>
                    <?php echo $link->matching_all == 1 ? 'MATCHING' : 'ALL' ?>
                </td>
            </tr>
            <?php
        }
        ?>
    </tbody>
</table>