<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class EteController extends JControllerLegacy{

}