<?php

// No direct access to this file

defined('_JEXEC') or die('Restricted access');

class EteControllerBackend extends JControllerLegacy {

    public function showRespondents() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('quizzes_respondents');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function showLinkReview() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('link_review');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function getQuestions() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('briefingbuilder_questions');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function getAnswers() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('briefingbuilder_answers');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function showAnswers() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('briefingbuilder_answers');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function showQuestionAnswers() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('briefingbuilder_qna');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function showAjaxQuestionAnswers() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('briefingbuilder_qna_ajax');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function addToBank() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('quizzes_bank');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function attachLink() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('quizzes_briefing_links');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function sendIds() {
        $model = $this->getModel('Backend');

        $view = $this->getView('backend', 'html');
        $view->setLayout('quizzes_briefing_sheets');
        $view->setModel($model, false);
        $view->display();

        die;
    }

    public function save() {
        
        $jinput = JFactory::getApplication()->input;
        $respondents = $jinput->get('uids', NULL, 'RAW');
        $url = $jinput->get('url', NULL, 'RAW');
        $intro = $jinput->get('intro', NULL, 'RAW');
        $matchingAll = $jinput->get('allMatching', 0, 'INT');
        
        $_respondents = explode("|", $respondents);
        $question_answer = explode("-", $_respondents[0]);
        
        $date = date('Y-m-d H:i:s');                
        
        // Get a db connection.
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $columns = array('url', 'intro', 'respondents', 'matching_all', 'date');
        
        $values = array($db->quote($url), $db->quote($intro), $db->quote($respondents), $db->quote($matchingAll), $db->quote($date));

        $query
                ->insert($db->quoteName('#__briefings'))
                ->columns($db->quoteName($columns))
                ->values(implode(',', $values));

        $db->setQuery($query);
        
        $send = $db->execute();        

        die($send);
    }

}
