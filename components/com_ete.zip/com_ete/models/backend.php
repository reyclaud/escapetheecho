<?php

defined('_JEXEC') or die('Restricted access');

class EteModelBackend extends JModelItem {

    protected $quizId;
    protected $questionName;

    public function __construct() {
        parent::__construct();

        $this->quizId = JRequest::getVar('quizId');
    }

    public function getForm() {

        if (!$this->quizId && JRequest::getVar('quizId')) {
            $this->quizId = JRequest::getVar('quizId');
        }

        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__rsform_forms');
        $query->where($db->quoteName('FormId') . ' = ' . $this->quizId);
        $db->setQuery((string) $query);

        $form = $db->loadObject();

        return $form;
    }

    public function getSubmissions() {

        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
//        $query->select('*, COUNT(`FieldName`) as times');
        $query->select('*');
        $query->from('#__rsform_submission_values');
        $query->where($db->quoteName('FormId') . ' = ' . $this->quizId);
//        $query->order($db->quoteName('FieldName') . ' ASC');
        $query->group($db->quoteName('FieldName'));
        $db->setQuery((string) $query);

        $selections = $db->loadObjectList();

        return $selections;
    }

    private function _getSubmissions() {

        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('a.*, b.Username, b.UserId');
        $query->from('#__rsform_submission_values AS a');
        $query->join('LEFT', '#__rsform_submissions AS b ON b.SubmissionId = a.SubmissionId');
        $query->where($db->quoteName('a.FormId') . ' = ' . $this->quizId);
        $query->order($db->quoteName('FieldName') . ' ASC');
        $db->setQuery((string) $query);

        $selections = $db->loadObjectList();

        return $selections;
    }

    public function _getQuestionName() {
        return JRequest::getVar('question');
    }

    public function _getQuestionSubmissions() {

        $this->questionName = JRequest::getVar('question');

        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('a.*, b.Username, b.UserId');
        $query->from('#__rsform_submission_values AS a');
        $query->join('LEFT', '#__rsform_submissions AS b ON b.SubmissionId = a.SubmissionId');
        $query->where($db->quoteName('a.FormId') . ' = ' . $this->quizId . ' AND ' . 'a.FieldName' . ' = ' . $db->quote($this->questionName));
        $query->order($db->quoteName('FieldName') . ' ASC');
        $db->setQuery((string) $query);

        $selections = $db->loadObjectList();

        return $selections;
    }

    public function getSubmissionAnswers() {

        $fieldNames = array();
        $submissions = $this->_getSubmissions();

        foreach ($submissions as $submission) {
            foreach (explode("\n", $submission->FieldValue) as $value) {
                if (isset($fieldNames[trim($submission->FieldName)][$value])) {
                    $fieldNames[trim($submission->FieldName)][$value] += 1;
                    $fieldNames['username'][trim($submission->FieldName)][$value][] = $submission->Username;
                    $fieldNames['userid'][trim($submission->FieldName)][$value][] = $submission->UserId;
                } else {
                    $fieldNames['userid'][trim($submission->FieldName)][$value][] = $submission->UserId;
                    $fieldNames['username'][trim($submission->FieldName)][$value][] = $submission->Username;
                    $fieldNames[trim($submission->FieldName)][$value] = 1;
                }
            }
        }

        return $fieldNames;
    }

    public function getQuestionAnswers() {

        $fieldNames = array();
//        $submissions = $this->_getQuestionSubmissions();
        $submissions = $this->_getSubmissions();

        foreach ($submissions as $submission) {
            foreach (explode("\n", $submission->FieldValue) as $value) {
                if (isset($fieldNames[trim($submission->FieldName)][$value])) {
                    $fieldNames[trim($submission->FieldName)][$value] += 1;
                    $fieldNames['username'][trim($submission->FieldName)][$value][] = $submission->Username;
                    $fieldNames['userid'][trim($submission->FieldName)][$value][] = $submission->UserId;
                } else {
                    $fieldNames['username'][trim($submission->FieldName)][$value][] = $submission->Username;
                    $fieldNames['userid'][trim($submission->FieldName)][$value][] = $submission->UserId;
                    $fieldNames[trim($submission->FieldName)][$value] = 1;
                }
            }
        }

        return $fieldNames;
    }

    public function getFormProperties() {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('ComponentId, PropertyName, PropertyValue');
        $query->from('#__rsform_properties');
        $query->where($db->quoteName('ComponentId') . ' IN (' . implode(',', $this->getFormComponentIds()) . ')');
        $query->order('ComponentId ASC');
        $db->setQuery((string) $query);

        $properties = $db->loadObjectList();

        $_properties = array();
        $_propertiesArr = array();

        foreach ($properties as $property) {
            $_properties[$property->ComponentId][$property->PropertyName] = $property->PropertyValue;
        }

        foreach ($properties as $_property) {
            if ($_property->PropertyName === 'NAME') {
                $_propertiesArr[trim($_property->PropertyValue)] = $_properties[$_property->ComponentId];
            }
        }

        return $_propertiesArr;
    }

    private function getFormComponents() {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__rsform_components');
        $query->where($db->quoteName('published') . ' = ' . 1 . ' AND ' . $db->quoteName('FormId') . ' = ' . $this->quizId);
        $query->order($db->quoteName('Order') . ' ASC');

        $db->setQuery((string) $query);

        $components = $db->loadObjectList();

        return $components;
    }

    private function getFormComponentIds() {
        $componentIds = array();
        $components = $this->getFormComponents();

        foreach ($components as $component) {
            array_push($componentIds, $component->ComponentId);
        }

        return $componentIds;
    }

    public function getRespondents() {
        $session = JFactory::getSession();
        $jinput = JFactory::getApplication()->input;

        if ($jinput->post->get('br_url', null, 'raw')) {
            $session->set('br_url', $jinput->post->get('br_url', null, 'raw'));
        }

        if ($jinput->post->get('br_description', null, 'raw')) {
            $session->set('br_description', $jinput->post->get('br_description', null, 'raw'));
        }

        if ($jinput->post->get('ids', array(), 'raw')) {
            $ids = json_decode($jinput->post->get('ids', array(), 'raw'), true);

            $session->set('ids', $ids);
            $respondents = array();

            foreach ($ids as $username) {
                $respondents[] = JFactory::getUser($username);
            }
        } else {
            $respondents = array();

            foreach ($session->get('ids') as $username) {
                $respondents[] = JFactory::getUser($username);
            }
        }

        return $respondents;
    }

    public function getLinkReviews() {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__briefings');
        $query->where($db->quoteName('respondents') . ' !=  ""');
        $query->order($db->quoteName('id') . ' ASC');

        $db->setQuery((string) $query);

        $links = $db->loadObjectList();

        return $links;
    }

}
